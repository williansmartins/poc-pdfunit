/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPMain.java 97 2013-10-28 07:39:47Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation;

/**
 * This program is the starting point of the 'Installation Verification Program'.
 * 
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPMain {

  private static VIP vip;
  private static String vipFile;
  private static String stylesheetFile;
  private static String htmlOut;

  /**
   * This program is the starting point of the 'Installation Verification Program'.
   */
  public static void main(String[] args) throws Exception {
    try {
      System.out.println("Checking installation ...");
      System.out.println("");
      parseCommandline(args);
      vip = new VIP(vipFile, stylesheetFile, htmlOut);
      vip.verifyInstallation();
      vip.exportXML();
      vip.exportHTML();
      System.out.println("... finished. Report created, see '" + vip.getOutHTML() + "' and '" + vip.getOutXML() + "'.");
    } catch (VIPException e) {            // This exception is thrown, when an installation error was detected.
      System.out.println(e.getMessage());
      VIP.showUsage();
    } catch (Exception e) {
      VIP.showUsage();
      e.printStackTrace();
    }
  }

  /**
   * The command line is parsed using the class VIPCommandLineParser.
   * <p>
   * Allowed parameters:
   * </p>
   * <ul>
   *   <li>--in    &lt;filename.vip&gt;</li>
   *   <li>--out   &lt;output_file.html&gt;</li>
   *   <li>--xslt  &lt;sindividual_stylesheet.xslt&gt; [optional]</li>
   * </ul>
   * 
   * @see VIPCommandLineParser
   */
  private static void parseCommandline(String[] args) throws VIPException {
    VIPCommandLineParser cmdParser = new VIPCommandLineParser();
//    System.out.println("===> args: " + args + "<===");
    cmdParser.parse(args);
    vipFile = cmdParser.getVIPFile();
    stylesheetFile = cmdParser.getStylesheetFile();
    htmlOut = cmdParser.getHTMLOutFile();
//    System.out.println("===> outHTML (2): " + htmlOut + "<===");
  }
  
}
