/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPLogger.java 104 2014-08-05 20:41:41Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation;

import java.io.File;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.verifyinstallation.objective.VIPApplication;
import org.verifyinstallation.objective.VIPClass;
import org.verifyinstallation.objective.VIPClasspath;
import org.verifyinstallation.objective.VIPExecutable;
import org.verifyinstallation.objective.VIPFile;
import org.verifyinstallation.objective.VIPFileProperty;
import org.verifyinstallation.objective.VIPFolder;
import org.verifyinstallation.objective.VIPJavaRuntime;
import org.verifyinstallation.objective.VIPNativeLibrary;
import org.verifyinstallation.objective.VIPOperatingSystem;
import org.verifyinstallation.objective.VIPSystemProperty;
import org.verifyinstallation.objective.VIPUrl;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Logging facilities. An internal XML document is hold during the validation,
 * which can be exported to a file.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPLogger {

  private String vipVersion = "1.0.0";
  private String vipLanguage = "Java";
  private static final String EMPTY_STRING = "";
  
  private Element rootElement;
  private Element librariesNode;
  private Element urlsNode;
  private Element executablesNode;
  private Element foldersNode;
  private Element filesNode;
  private Element systemPropertiesNode;
  private Element filePropertiesNode;

  private Document resultDOM;
  private Element errorsNode;
  private int numberOfErrors;

  public VIPLogger() {
    try {
      DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

      resultDOM = docBuilder.newDocument();
      createRootElement();
      errorsNode = createNode("errors");
      rootElement.appendChild(errorsNode);
      
      resultDOM.appendChild(rootElement);
    } catch (DOMException e) {
      String msg = e.getMessage();
      this.addError(msg, e);  // NOPMD ConstructorCallsOverridableMethod
    } catch (ParserConfigurationException e) {
      String msg = e.getMessage();
      this.addError(msg, e);  // NOPMD ConstructorCallsOverridableMethod
    }
  }

  private void createRootElement() {
    rootElement = resultDOM.createElement("verify.installation.report");
    rootElement.setAttribute("vipVersion", vipVersion);
    rootElement.setAttribute("language", vipLanguage);

    Element dateNode = createNode("date");
    String currentTime = getCurrentTime();
    dateNode.setTextContent(currentTime);
    rootElement.appendChild(dateNode);
  }

  /**
   * Writing a report into a file.
   */
  public void exportXML(String outXML) throws TransformerException {
    errorsNode.setAttribute("count", "" + numberOfErrors);
    
    DOMSource source = new DOMSource(resultDOM);
    StreamResult outputTarget =  new StreamResult(outXML);
//    System.out.println("===> outputTarget: " + outputTarget + "<===");

    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    transformer.setOutputProperty("{http://xml.apache.org/xalan}indent-amount", "2");
    transformer.transform(source, outputTarget);
  }

  public void exportHTML(String stylesheet, String outHTML) throws TransformerException, VIPException {
    errorsNode.setAttribute("count", "" + numberOfErrors);
    
    DOMSource source = new DOMSource(resultDOM);
    Source xsltSource = createStylesheetSource(stylesheet);
    StreamResult outputTarget = new StreamResult(outHTML);

    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer(xsltSource);
    transformer.transform(source, outputTarget);
  }
  
  /**
   * Logging all common data of the application.
   */
  public void log(VIPApplication application) {
    String product = application.getProduct();
    String version = application.getVersion();
    String comment = application.getComment();

    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    Element applicationNode = createNode("application");
    rootElement.appendChild(applicationNode);
    applicationNode.setAttribute("product", product);
    applicationNode.setAttribute("version", version);
    applicationNode.appendChild(commentNode);
    
    Element directoryNode = createNode("workdirectory");
    String workDirectory = application.getWorkDirectory();
    directoryNode.setAttribute("dir", workDirectory);
    
    Element canReadNode = createNode("attribute");
    Element canWriteNode = createNode("attribute");
    
    File dir = new File(workDirectory);
    boolean canReadActual = dir.canRead();
    boolean canWriteActual = dir.canWrite();
    
    canReadNode.setAttribute("name", "canRead");
    canReadNode.setAttribute("actual", "" + canReadActual);
    canWriteNode.setAttribute("name", "canWrite");
    canWriteNode.setAttribute("actual", "" + canWriteActual);
    directoryNode.appendChild(canReadNode);
    directoryNode.appendChild(canWriteNode);
    
    applicationNode.appendChild(directoryNode);
  }

  /**
   * Logging the data of a native library.
   */
  public void log(VIPNativeLibrary nativeLibrary) {
    String libraryName = nativeLibrary.getName();
    boolean loadable = nativeLibrary.isLoadable();

    String comment = nativeLibrary.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    Element libraryNode = createNode("library");
    libraryNode.setAttribute("name", libraryName);
    libraryNode.setAttribute("canRead", "" + loadable);

    libraryNode.appendChild(commentNode);

    Element librariesNode = getNodeLibraries();
    librariesNode.appendChild(libraryNode);

    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (!loadable) {
      String msg = "'" + libraryName + "' could not be loaded.";
      addError(msg);
    }
  }

  /**
   * Logging the existence of an URL.
   */
  public void log(VIPUrl url) {
    String comment = url.getComment();
    String location = url.getLocation();
    boolean canRead = url.canReadActual();
    
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    Element urlNode = createNode("url");
    urlNode.setAttribute("location", location);
    urlNode.appendChild(commentNode);
    urlNode.setAttribute("canRead", "" + canRead);

    Element urlsNode = getNodeURLs();
    urlsNode.appendChild(urlNode);
    
    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (!canRead) {
      String msg = "'" + location + "' could not be read.";
      addError(msg);
    }
  }

  /**
   * Logging the data of the operating system.
   */
  public void log(VIPOperatingSystem os) {
    String comment = os.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    Element expectedNode = createNode("expected");
    String expectedOS = os.getExpectedOperatingSystem();
    String expectedVersions = os.getExpectedOSVersions();
    String expectedBitSystem = os.getExpectedBitSystem();
    expectedNode.setAttribute("name", expectedOS);
    expectedNode.setAttribute("bitSystem", expectedBitSystem);
    expectedNode.setAttribute("versions", expectedVersions);
    
    Element actualNode = createNode("actual");
    String actualOS = os.getActualOperatingSystem();
    String actualActualBitSystem = os.getActualBitSystem();
    actualNode.setAttribute("bitSystem", actualActualBitSystem);
    actualNode.setAttribute("name", actualOS);
    
    Element osNode = createNode("os");
    osNode.appendChild(commentNode);
    osNode.appendChild(expectedNode);
    osNode.appendChild(actualNode);
    rootElement.appendChild(osNode);
    
    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (expectedOS != null && expectedVersions != null) {
      boolean isExpectedOperatingSystem = isExpectedOperatingSystem(expectedOS, expectedVersions);
      if (!isExpectedOperatingSystem) {
        String msg = "Wrong operating system. Expected: '" + expectedOS + "', actual: '" + actualOS + "'.";
        addError(msg);
      }
    }
    
    if (expectedBitSystem != null) {
      boolean isExpectedBitSystem = isExpectedBitSystem(expectedBitSystem);
      if (!isExpectedBitSystem) {
        String msg = "Wrong number of bits. Expected: '" + expectedBitSystem + "', actual: '" + actualActualBitSystem + "'.";
        addError(msg);
      }
    }
  }
  
  public void log(VIPExecutable executable) {
    String comment = executable.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);

    String executableName = executable.getExecutableName();
    String parentDirectory = executable.getParentDirectory();
    String expectedOperatingSystem = executable.getExpectedOperatingSystem();
    String actualOperatingSystem = executable.getActualOperatingSystem();
    boolean foundInPath = executable.foundInPath();
    
    Element executableNode = createNode("executable");
    executableNode.appendChild(commentNode);
    executableNode.setAttribute("name", executableName);
    executableNode.setAttribute("found", "" + foundInPath);

    if (foundInPath) {
      Element parentDirNode = createNode("parentDirectory");
      parentDirNode.setTextContent(parentDirectory);
      executableNode.appendChild(parentDirNode);
    }
    
    Element attributeNode = createNode("os");
    attributeNode.setAttribute("expected", expectedOperatingSystem);
    attributeNode.setAttribute("actual", actualOperatingSystem);
    executableNode.appendChild(attributeNode);
  
    Element executablesNode = getNodeExecutables();
    executablesNode.appendChild(executableNode);
    
    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (expectedOperatingSystem != null) {
      boolean isExpectedOperatingSystem = isExpectedOperatingSystem(expectedOperatingSystem);
      if (isExpectedOperatingSystem) {
        if (!foundInPath) {
          String msg = "Executable '" + executableName + "' not found in PATH.";
          addError(msg);
        }
      } else {
        ; // NOPMD EmptyIfStmt
        // Report an error only, when the operating system is correct. 
      }
    }
  }

  public void log(VIPJavaRuntime javaRuntime) {
    String comment = javaRuntime.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    String actualJavaVersion = javaRuntime.getActualJavaVersion();
    String actualBitSystem = javaRuntime.getActualBitSystem();
    String actualJavaVendor = javaRuntime.getActualJavaVendor();
    String actualJavaClassVersion = javaRuntime.getJavaClassVersion();
    String actualJavaSpecificationVersion = javaRuntime.getJavaSpecificationVersion();
    
    String expectedJavaVersion = javaRuntime.getExpectedVersion(); 
    String expectedBitSystem = javaRuntime.getExpectedBitSystem();
    
    Element expectedNode = createNode("expected");
    expectedNode.setAttribute("bitSystem", expectedBitSystem);
    expectedNode.setAttribute("version", expectedJavaVersion);
    
    Element actualNode = createNode("actual");
    actualNode.setAttribute("bitSystem", actualBitSystem);
    actualNode.setAttribute("version", actualJavaVersion);
    actualNode.setAttribute("vendor", actualJavaVendor);
    actualNode.setAttribute("classVersion", actualJavaClassVersion);
    actualNode.setAttribute("specificationVersion", actualJavaSpecificationVersion);
    
    Element javaRuntimeNode = createNode("javaRuntime");
    javaRuntimeNode.appendChild(expectedNode);
    javaRuntimeNode.appendChild(actualNode);

    rootElement.appendChild(javaRuntimeNode);

    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (expectedBitSystem == null) {
      ; // No reporting, when nothing is expected
    } else {
      boolean isExpectedBitSystem = isExpectedBitSystem(expectedBitSystem);
      if (!isExpectedBitSystem) {
        String msg = "Wrong number of bits. Expected: '" + expectedBitSystem + "', actual: '" + actualBitSystem + "'.";
        addError(msg);
      }
    }

    if (expectedJavaVersion == null) {
      ; // No reporting, when nothing is expected
    } else {
      boolean isExpectedJavaVersion = isExpectedJavaVersion(expectedJavaVersion);
      if (!isExpectedJavaVersion) {
        String msg = "Wrong version of Java runtime. Expected: '" + expectedJavaVersion + "', actual: '" + actualJavaVersion + "'.";
        addError(msg);
      }
    }
  }

  /**
   * Logging all parts of the current classpth.
   */
  public void log(VIPClasspath classpath) {
    Element classpathNode = createNode("classpath");
    rootElement.appendChild(classpathNode);
    
    String[] pathEntries = classpath.getPathEntries();
    for (int i = 0; i < pathEntries.length; i++) {
      Element classNode = createNode("location");
      classNode.setTextContent(pathEntries[i]);
      classpathNode.appendChild(classNode);
    }
  }

  /**
   * Log classes and whether they are loaded.
   */
  public void log(Vector<? extends VIPClass> classes) {
    Element classpathNode = createNode("classes.in.classpath");
    rootElement.appendChild(classpathNode);
    for (VIPClass vipClass : classes) {
      String comment = vipClass.getComment();
      String name = vipClass.getName();
      boolean loadable = vipClass.isLoadable();
      String classLocation = vipClass.getLocation();
      String classVersion = vipClass.getClassVersion();

      Element classNode = createNode("class");
      classNode.setAttribute("name", name);
      classNode.setAttribute("comment", comment);
      classNode.setAttribute("loadable", "" + loadable);
      classNode.setAttribute("loadedFrom", classLocation);
      classNode.setAttribute("version", classVersion);
      classpathNode.appendChild(classNode);
      
      ///////////////////////////////////////////////////////////////////////////
      // Check for installation errors:
      ///////////////////////////////////////////////////////////////////////////
      if (!loadable) {
        String msg = "'" + name + "' could not be loaded.";
        addError(msg);
      }
    }
  }
  
  public void logFilesInClasspath(Vector<VIPFile> classpathFiles) {
    Element filesNode = createNode("files.in.classpath");
    rootElement.appendChild(filesNode);
    for (VIPFile vipFile : classpathFiles) {
      String comment = vipFile.getComment();
      String name = vipFile.getName();
      String location = vipFile.getLocation();

      Element commentNode = createNode("comment");
      commentNode.setTextContent(comment);
      
      Element fileNode = createNode("file");
      fileNode.appendChild(commentNode);
      
      fileNode.setAttribute("name", name);

      fileNode.setAttribute("exists", "" + vipFile.exists());
      if (vipFile.exists()) {
        Element canReadNode = createNode("attribute");
        Element canWriteNode = createNode("attribute");
        Element canExecuteNode = createNode("attribute");
        
        fileNode.setAttribute("loadedFrom", location);

        canReadNode.setAttribute("name", "canRead");
        canWriteNode.setAttribute("name", "canWrite");
        canExecuteNode.setAttribute("name", "canExecute");
        
        canReadNode.setAttribute("expected", vipFile.getCanReadExpected());
        canWriteNode.setAttribute("expected", vipFile.getCanWriteExpected());
        canExecuteNode.setAttribute("expected", vipFile.getCanExecuteExpected());
        
        canReadNode.setAttribute("actual", vipFile.getCanReadActual());
        canWriteNode.setAttribute("actual", vipFile.getCanWriteActual());
        canExecuteNode.setAttribute("actual", vipFile.getCanExecuteActual());
        
        fileNode.appendChild(canReadNode);
        fileNode.appendChild(canWriteNode);
        fileNode.appendChild(canExecuteNode);
      }
      filesNode.appendChild(fileNode);

      ///////////////////////////////////////////////////////////////////////////
      // Check for installation errors:
      ///////////////////////////////////////////////////////////////////////////
      if (!vipFile.exists()) {
        String msg = "File '" + name + "' does not exist.";
        addError(msg);
      }
    }
  }

  /**
   * Logging the data of folders to XML.
   */
  public void log(VIPFolder vipFolder) {
    String comment = vipFolder.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    Element folderNode = createNode("folder");
    String folderName = vipFolder.getName();
    folderNode.setAttribute("name", folderName);
    folderNode.appendChild(commentNode);
    
    File folder = new File(folderName);
    boolean exists = folder.exists();
    folderNode.setAttribute("exists", "" + exists);
    if (exists) {
      Element canReadNode = createNode("attribute");
      Element canWriteNode = createNode("attribute");
      boolean canReadActual = folder.canRead();
      boolean canWriteActual = folder.canWrite();
      String canReadExpected = vipFolder.getCanReadExpected();
      String canWriteExpected = vipFolder.getCanWriteExpected();
      canReadNode.setAttribute("name", "canRead");
      canReadNode.setAttribute("expected", canReadExpected);
      canReadNode.setAttribute("actual", "" + canReadActual);
      canWriteNode.setAttribute("name", "canWrite");
      canWriteNode.setAttribute("expected", canWriteExpected);
      canWriteNode.setAttribute("actual", "" + canWriteActual);
      folderNode.appendChild(canReadNode);
      folderNode.appendChild(canWriteNode);
    }
    Element foldersNode = getNodeFolders();
    foldersNode.appendChild(folderNode);

    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (!exists) {
      String msg = "Folder '" + folderName + "' does not exist.";
      addError(msg);
    }
  }

  /**
   * Logging the data of a file.
   */
  public void log(VIPFile vipFile) {
    String comment = vipFile.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    Element fileNode = createNode("file");
    String fileName = vipFile.getName();
    fileNode.setAttribute("name", fileName);
    fileNode.appendChild(commentNode);
    
    File folder = new File(fileName);
    boolean exists = folder.exists();
    fileNode.setAttribute("exists", "" + exists);
    if (exists) {
      Element canReadNode = createNode("attribute");
      Element canWriteNode = createNode("attribute");
      Element canExecuteNode = createNode("attribute");
      
      boolean canReadActual = folder.canRead();
      boolean canWriteActual = folder.canWrite();
      boolean canExecuteActual = folder.canExecute();
      
      String canReadExpected = vipFile.getCanReadExpected();
      String canWriteExpected = vipFile.getCanWriteExpected();
      String canExecuteExpected = vipFile.getCanExecuteExpected();
      
      canReadNode.setAttribute("name", "canRead");
      canReadNode.setAttribute("expected", canReadExpected);
      canReadNode.setAttribute("actual", "" + canReadActual);
      
      canWriteNode.setAttribute("name", "canWrite");
      canWriteNode.setAttribute("expected", canWriteExpected);
      canWriteNode.setAttribute("actual", "" + canWriteActual);
      
      canExecuteNode.setAttribute("name", "canExecute");
      canExecuteNode.setAttribute("expected", canExecuteExpected);
      canExecuteNode.setAttribute("actual", "" + canExecuteActual);
      fileNode.appendChild(canReadNode);
      fileNode.appendChild(canWriteNode);
      fileNode.appendChild(canExecuteNode);
    }
    Element filesNode = getNodeFiles();
    filesNode.appendChild(fileNode);

    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (!exists) {
      String msg = "File '" + fileName + "' does not exist.";
      addError(msg);
    }
  }

  /**
   * Log system properties.
   */
  public void log(VIPSystemProperty systemProperty) {
    String comment = systemProperty.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    String key = systemProperty.getKey();
    String expectedValue = systemProperty.getExpectedValue();
    String actualValue = systemProperty.getActualValue();
    boolean keyExists = systemProperty.doesKeyExist();

    Element propertyNode = createNode("property");
    propertyNode.setAttribute("key", key);
    propertyNode.setAttribute("exists", "" + keyExists);
    propertyNode.appendChild(commentNode);

    if (keyExists) {
      Element valueNode = createNode("value");
      valueNode.setAttribute("expected", expectedValue);
      valueNode.setAttribute("actual", actualValue);
      propertyNode.appendChild(valueNode);
    }
    
    Element propertiesNode = getNodeSystemProperties();
    propertiesNode.appendChild(propertyNode);

    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (!keyExists) {
      String msg = "Property with key '" + key + "' does not exist in system properties.";
      addError(msg);
    }
    if (expectedValue != null && !expectedValue.equals(actualValue)) {
      String msg = "Wrong value in system property '" + key + "'. Expected: '" + expectedValue + "', actual: '" + actualValue + "'.";
      addError(msg);
    }
  }
    
  /**
   * Log the data of file properties.
   */
  public void log(VIPFileProperty fileProperty) {
    String comment = fileProperty.getComment();
    Element commentNode = createNode("comment");
    commentNode.setTextContent(comment);
    
    String filename = fileProperty.getFilename();
    String key = fileProperty.getKey();
    String expectedValue = fileProperty.getExpectedValue();
    String actualValue = fileProperty.getActualValue();
    boolean fileExists = fileProperty.doesFileExist();
    boolean keyExists = fileProperty.doesKeyExist();

    Element propertyNode = createNode("property");
    propertyNode.setAttribute("key", key);
    propertyNode.setAttribute("file", filename);
    propertyNode.setAttribute("fileExist", "" + fileExists);
    propertyNode.setAttribute("keyExist", "" + keyExists);
    propertyNode.appendChild(commentNode);
    
    if (fileExists) {
      Element valueNode = createNode("value");
      valueNode.setAttribute("expected", expectedValue);
      valueNode.setAttribute("actual", actualValue);
      propertyNode.appendChild(valueNode);
    }
    
    Element propertiesNode = getNodeFileProperties();
    propertiesNode.appendChild(propertyNode);

    ///////////////////////////////////////////////////////////////////////////
    // Check for installation errors:
    ///////////////////////////////////////////////////////////////////////////
    if (!fileExists) {
      String msg = "Property file '" + filename + "' not found.";
      addError(msg);
    }
    
    if (!keyExists && fileExists) {
      String msg = "Key '" + key + "' does not exist in property file '" + filename + "'.";
      addError(msg);
    }
    
    if (!EMPTY_STRING.equals(expectedValue) && !expectedValue.equals(actualValue)) {
      String msg = "Wrong value in property file '" + filename + "' for key '" + key + "'. Expected: '" + expectedValue + "', actual: '" + actualValue + "'.";
      addError(msg);
    }
  }

  /**
   * Adding an error to the internal error log.
   */
  public void addError(String msg, Exception e) {
    Element errorNode = createNode("error");
    errorNode.setTextContent(msg);
    
    Element exceptionNode = createNode("exception");
    StringWriter writer = new StringWriter();
    PrintWriter pw = new PrintWriter(writer); 
    e.printStackTrace(pw);
    
    String exceptionText = writer.toString();
    exceptionNode.setTextContent(exceptionText);
    
    errorsNode.appendChild(errorNode);
    numberOfErrors++;
  }

  public void addError(String msg) {
    Element errorNode = createNode("error");
    errorNode.setTextContent(msg);
    errorsNode.appendChild(errorNode);
    numberOfErrors++;
  }

  /////////////////////////////////////////////////////////////////////////////
  // Helper methods, validating:
  /////////////////////////////////////////////////////////////////////////////
  
  private boolean isExpectedOperatingSystem(String... expectedOSVersion) {
    String osName = System.getProperty("os.name").toLowerCase();  // NOPMD UseLocaleWithCaseConversions
    for (int i = 0; i < expectedOSVersion.length; i++) {
      String expectedOS = expectedOSVersion[i];
      if (osName != null && osName.toLowerCase().contains(expectedOS.toLowerCase())) { // NOPMD UseLocaleWithCaseConversions
        return true;
      }
    }
    return false;
  }

  private boolean isExpectedBitSystem(String expectedBitSystem) {
    String osArch = System.getProperty("os.arch");
    if (expectedBitSystem != null && osArch.contains(expectedBitSystem)) {
      return true;
    }
    return false;
  }

  private boolean isExpectedJavaVersion(String expectedJavaVersion) {
    String actualJavaVersion = System.getProperty("java.version");
    if (actualJavaVersion != null && expectedJavaVersion.endsWith("+")) {
      if (actualJavaVersion.compareTo(expectedJavaVersion) >= 0) {
        return true;
      }
    } else {
      if (actualJavaVersion.startsWith(expectedJavaVersion)) {
        return true;
      }
    }
    return false;
  }

  /////////////////////////////////////////////////////////////////////////////
  // Helper methods, not logging:
  /////////////////////////////////////////////////////////////////////////////
  
  private Source createStylesheetSource(String stylesheet) throws VIPException {
    if (VIP.defaultStylesheet.equals(stylesheet)) {
      // Load default stylesheet from jar:
      InputStream input = this.getClass().getClassLoader().getResourceAsStream(VIP.defaultStylesheet);
      if (input == null) {
        String msg = "The stylesheet '" + stylesheet + "' could not be parsed.";
        throw new VIPException(msg);
      }
      return new StreamSource(input);
    } else {
      File xsltFile = new File(stylesheet);
      return new StreamSource(xsltFile);
    }
  }

  private String getCurrentTime() {
    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss"); // NOPMD SimpleDateFormatNeedsLocale
    Date now = new Date();
    String formattedDate = formatter.format(now);
    return formattedDate;
  }

  private Element createNode(String nodeName) {
    Element newElement = resultDOM.createElement(nodeName);
    return newElement;
  }

  private Element getNodeLibraries() {
    if (this.librariesNode == null) {
      this.librariesNode = createNode("libraries");
      rootElement.appendChild(librariesNode);
    }
    return librariesNode;
  }

  private Element getNodeURLs() {
    if (this.urlsNode == null) {
      this.urlsNode = createNode("urls");
      rootElement.appendChild(urlsNode);
    }
    return urlsNode;
  }
  
  private Element getNodeExecutables() {
    if (this.executablesNode == null) {
      this.executablesNode = createNode("executables");
      rootElement.appendChild(executablesNode);
    }
    return executablesNode;
  }

  private Element getNodeFolders() {
    if (this.foldersNode == null) {
      this.foldersNode = createNode("folders");
      rootElement.appendChild(foldersNode);
    }
    return foldersNode;
  }

  private Element getNodeFiles() {
    if (this.filesNode == null) {
      this.filesNode = createNode("files");
      rootElement.appendChild(filesNode);
    }
    return filesNode;
  }

  private Element getNodeSystemProperties() {
    if (this.systemPropertiesNode == null) {
      this.systemPropertiesNode = createNode("systemProperties");
      rootElement.appendChild(systemPropertiesNode);
    }
    return systemPropertiesNode;
  }

  private Element getNodeFileProperties() {
    if (this.filePropertiesNode == null) {
      this.filePropertiesNode = createNode("fileProperties");
      rootElement.appendChild(filePropertiesNode);
    }
    return filePropertiesNode;
  }

  public boolean hasErrors() {
    if (numberOfErrors > 0) {
      return true;
    } else {
      return false;
    }
  }

}
