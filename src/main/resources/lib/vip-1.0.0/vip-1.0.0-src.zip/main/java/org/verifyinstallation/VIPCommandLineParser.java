/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPCommandLineParser.java 97 2013-10-28 07:39:47Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation;

import java.util.ArrayList;

/**
 * Parsing the command line for the VIP (Verify Installation Program)
 * 
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPCommandLineParser {

  private String vipFile;    // mandatory parameter
  private String stylesheet; // optional  parameter
  private String htmlOut;    // optional  parameter


  public void parse(String[] args) throws VIPException {
    if (args.length % 2 != 0) {
      String msg = "Error: Wrong command line, the number of command line arguments must be even.";
      throw new VIPException(msg);
    }
    
    ArrayList<String> argList = new ArrayList<String>();
    for (String arg : args) {
//      System.out.println("===> arg: " + arg + "<===");
      argList.add(arg);
    }
    searchVIPFile(argList);
    searchStylesheetFile(argList);
    searchHTMLOutFile(argList);
  }

  private void searchVIPFile(ArrayList<String> argList) throws VIPException {
//    System.out.println("===> argList: " + argList + "<===");
    int indexOfKeyword = argList.indexOf("--in");
    if (indexOfKeyword == -1) {
      String msg = "Error: No validation file given.";
      throw new VIPException(msg);
    } else {
      this.vipFile = argList.get(indexOfKeyword + 1);
    }
  }

  private void searchStylesheetFile(ArrayList<String> argList) {
    int indexOfKeyword = argList.indexOf("--xslt");
    if (indexOfKeyword == -1) {
      this.stylesheet = VIP.defaultStylesheet;
    } else {
      this.stylesheet = argList.get(indexOfKeyword + 1);
    }
  }

  private void searchHTMLOutFile(ArrayList<String> argList) {
//    System.out.println("===> argList: " + argList + "<===");
    int indexOfKeyword = argList.indexOf("--out");
//    System.out.println("===> argList.indexOf('--out'): " + indexOfKeyword + "<===");
    if (indexOfKeyword == -1) {
      this.htmlOut = VIP.defaultOutputHTML;
    } else {
      this.htmlOut = argList.get(indexOfKeyword + 1);
    }
//    System.out.println("===> outHTML (1): " + this.htmlOut + "<===");
  }

  public String getVIPFile() {
    return vipFile;
  }

  public String getStylesheetFile() {
    return stylesheet;
  }

  public String getHTMLOutFile() {
    return htmlOut;
  }
  
}
