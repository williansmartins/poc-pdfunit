/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPNativeLibrary.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to a loadable library.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPNativeLibrary {

  private String name;
  private String comment;
  private boolean loadable;

  public void setName(String name) {
    this.name = name;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getName() {
    return name;
  }

  public String getComment() {
    return comment;
  }

  public void setLoadable(boolean loadable) {
    this.loadable = loadable;
  }
  
  public boolean isLoadable() {
    return loadable;
  }
  
}
