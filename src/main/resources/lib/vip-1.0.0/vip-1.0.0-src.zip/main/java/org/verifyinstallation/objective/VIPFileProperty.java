/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPFileProperty.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to a file property.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPFileProperty {

  private String filename  = "";
  private String key       = "";
  private String expectedValue  = "";
  private String comment   = "";
  private String actualValue;
  private boolean fileExists;
  private boolean keyExists;

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public void setExpectedValue(String expectedValue) {
    this.expectedValue = expectedValue;
  }

  public void setActualValue(String actualValue) {
    this.actualValue = actualValue;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getFilename() {
    return filename;
  }

  public String getKey() {
    return key;
  }

  public String getExpectedValue() {
    return expectedValue;
  }

  public String getActualValue() {
    return actualValue;
  }

  public String getComment() {
    return comment;
  }

  public boolean doesFileExist() {
    return fileExists;
  }

  public void setFileExists(boolean fileExists) {
    this.fileExists = fileExists;
  }

  public boolean doesKeyExist() {
    return keyExists;
  }

  public void setKeyExists(boolean keyExists) {
    this.keyExists = keyExists;
  }

}
