/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPJavaRuntime.java 100 2014-04-11 20:58:10Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to the current Java runtime.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPJavaRuntime {

  private String comment;
  private String expectedBitSystem;
  private String version;
  private String actualJavaVendor;
  private String actualJavaVersion;
  private String actualBitSystem;
  private String javaSpecificationVersion;
  private String javaClassVersion;

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setExpectedBitSystem(String bitSystem) {
    this.expectedBitSystem = bitSystem;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getComment() {
    return comment;
  }

  public String getExpectedBitSystem() {
    return expectedBitSystem;
  }

  public String getExpectedVersion() {
    return version;
  }

  public void setActualBitSystem(String actualBitSystem) {
    this.actualBitSystem = actualBitSystem;
  }

  public void setActualJavaVendor(String actualJavaVendor) {
    this.actualJavaVendor = actualJavaVendor;
  }

  public void setActualJavaVersion(String actualJavaVersion) {
    this.actualJavaVersion = actualJavaVersion;
  }

  public void setSpecificationVersion(String javaSpecificationVersion) {
    this.javaSpecificationVersion = javaSpecificationVersion;
  }

  public void setClassVersion(String javaClassVersion) {
    this.javaClassVersion = javaClassVersion;
  }

  public String getActualJavaVendor() {
    return actualJavaVendor;
  }

  public String getActualJavaVersion() {
    return actualJavaVersion;
  }

  public String getActualBitSystem() {
    return actualBitSystem;
  }

  public String getJavaClassVersion() {
    return javaClassVersion;
  }
  
  public String getJavaSpecificationVersion() {
    return javaSpecificationVersion;
  }
  
}
