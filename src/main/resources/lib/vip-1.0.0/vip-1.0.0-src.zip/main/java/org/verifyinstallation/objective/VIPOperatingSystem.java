/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPOperatingSystem.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to the current operating system.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPOperatingSystem {

  private String comment;
  
  private String expectedName;
  private String expectedBitSystem;
  private String expectedOSVersions;

  private String actualBitSystem;
  private String actualOperatingSystem;

  public void setExpectedName(String name) {
    this.expectedName = name;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setExpectedBitSystem(String bitSystem) {
    this.expectedBitSystem = bitSystem;
  }

  public void setExpectedOSVersions(String versions) {
    this.expectedOSVersions = versions;
  }

  public String getExpectedOSVersions() {
    return expectedOSVersions;
  }

  public String getExpectedOperatingSystem() {
    return expectedName;
  }

  public String getComment() {
    return comment;
  }

  public String getExpectedBitSystem() {
    return expectedBitSystem;
  }

  public void setActualOperatingSystem(String actualOperatingSystem) {
    this.actualOperatingSystem = actualOperatingSystem;
  }

  public void setActualBitSystem(String actualBitSystem) {
    this.actualBitSystem = actualBitSystem;
  }

  public String getActualBitSystem() {
    return actualBitSystem;
  }

  public String getActualOperatingSystem() {
    return actualOperatingSystem;
  }

}
