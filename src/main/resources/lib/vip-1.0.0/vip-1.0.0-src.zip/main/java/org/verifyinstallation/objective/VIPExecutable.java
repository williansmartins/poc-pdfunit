/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPExecutable.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to an executable.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPExecutable {

  private String processName;
  private String expectedOperatingSystem;
  private String comment;
  private String directory;
  private boolean foundInPath;
  private String actualOperatingSystem;

  public void setExpectedOperatingSystem(String operatingSystem) {
    this.expectedOperatingSystem = operatingSystem;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setExecutableName(String processName) {
    this.processName = processName;
  }

  public String getExpectedOperatingSystem() {
    return expectedOperatingSystem;
  }

  public String getExecutableName() {
    return processName;
  }
  
  public String getComment() {
    return comment;
  }

  public void setParentDirectory(String directory) {
    this.directory = directory;
  }
  
  public String getParentDirectory() {
    return directory;
  }

  public void foundInPath(boolean foundInPath) {
    this.foundInPath = foundInPath;
  }
  
  public boolean foundInPath() {
    return foundInPath;
  }
  
  public void setActualOperatingSystem(String actualOperatingSystem) {
    this.actualOperatingSystem = actualOperatingSystem;
  }

  public String getActualOperatingSystem() {
    return actualOperatingSystem;
  }
  
}
