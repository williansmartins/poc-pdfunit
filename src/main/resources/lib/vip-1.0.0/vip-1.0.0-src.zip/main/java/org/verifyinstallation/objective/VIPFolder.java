/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPFolder.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to a folder.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPFolder {

  private String name;
  private String canReadExpected;
  private String canWriteExpected;
  private String comment;

  public void setName(String name) {
    this.name = name;
  }

  public void setCanReadExpected(String canRead) {
    this.canReadExpected = canRead;
  }

  public void setCanWriteExpected(String canWrite) {
    this.canWriteExpected = canWrite;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getName() {
    return name;
  }

  public String getCanReadExpected() {
    return canReadExpected;
  }

  public String getCanWriteExpected() {
    return canWriteExpected;
  }

  public String getComment() {
    return comment;
  }
  
}
