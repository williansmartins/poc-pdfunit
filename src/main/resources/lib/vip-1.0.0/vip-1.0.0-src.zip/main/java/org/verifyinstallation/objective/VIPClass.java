/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPClass.java 100 2014-04-11 20:58:10Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to a class.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPClass {

  private String comment;
  private String name;
  private boolean loadable;
  private String classLocation;
  private String classVersion;

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setClass(String name) {
    this.name = name;
  }

  public String getComment() {
    return comment;
  }
  
  public String getName() {
    return name;
  }

  public void setLoadable(boolean loadable) {
    this.loadable = loadable;
  }
  
  public boolean isLoadable() {
    return loadable;
  }

  public void setLocation(String classLocation) {
    this.classLocation = classLocation;
  }

  public String getLocation() {
    return classLocation;
  }

  public void setClassVersion(String classVersion) {
    this.classVersion = classVersion;
  }
  
  public String getClassVersion() {
    return classVersion;
  }
  
}
