/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPApplication.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to an application.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPApplication {

  private String product;
  private String version;
  private String comment;
  private String workDirectory;

  public void setProduct(String product) {
    this.product = product;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }
  
  public String getProduct() {
    return product;
  }

  public String getVersion() {
    return version;
  }

  public String getComment() {
    return comment;
  }

  public void setWorkDirectory(String currentDir) {
    this.workDirectory = currentDir;
  }

  public String getWorkDirectory() {
    return workDirectory;
  }
  
}
