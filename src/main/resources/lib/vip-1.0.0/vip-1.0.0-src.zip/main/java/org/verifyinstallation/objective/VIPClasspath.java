/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPClasspath.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container holding all classpath entries.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPClasspath {

  private String[] pathEntries;

  public void setPathEntries(String[] pathEntries) { // NOPMD ArrayIsStoredDirectly
    this.pathEntries = pathEntries;  
  }

  public String[] getPathEntries() {
    return pathEntries; // NOPMD ArrayIsStoredDirectly
  }
  
}
