/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPSystemProperty.java 47 2013-10-24 15:54:00Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to a system property.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPSystemProperty {

  private String key;
  private String expectedValue;
  private String actualValue;
  private String comment;
  private boolean keyExists;

  public void setKey(String key) {
    this.key = key;
  }

  public void setExpectedValue(String value) {
    this.expectedValue = value;
  }

  public void setActualValue(String value) {
    this.actualValue = value;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getKey() {
    return key;
  }

  public String getExpectedValue() {
    return expectedValue;
  }

  public String getActualValue() {
    return actualValue;
  }

  public String getComment() {
    return comment;
  }

  public boolean doesKeyExist() {
    return keyExists;
  }

  public void setKeyExists(boolean isKeyExists) {
    this.keyExists = isKeyExists;
  }

}
