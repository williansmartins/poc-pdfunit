/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPFile.java 104 2014-08-05 20:41:41Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation.objective;

/**
 * Container for all data belonging to a file.
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPFile {

  private String name               = ""; 
  private String comment            = "";
  private String canExecuteExpected = "";
  private String canWriteExpected   = "";
  private String canReadExpected    = "";
  private String canReadActual      = "";
  private String canWriteActual     = "";
  private String canExecuteActual   = "";
  private String location           = "";
  private boolean exists;

  public void setName(String name) {
    this.name = name;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setCanReadExpected(String canRead) {
    this.canReadExpected = canRead;
  }

  public void setCanWriteExpected(String canWrite) {
    this.canWriteExpected = canWrite;
  }

  public void setCanExecuteExpected(String canExecute) {
    this.canExecuteExpected = canExecute;
  }

  public void setCanReadActual(String canRead) {
    this.canReadActual = canRead;
  }
    
  public void setCanWriteActual(String canWrite) {
    this.canWriteActual = canWrite;
  }
  
  public void setCanExecuteActual(String canExecute) {
    this.canExecuteActual = canExecute;
  }
  
  public String getName() {
    return name;
  }

  public String getComment() {
    return comment;
  }

  public String getCanExecuteExpected() {
    return canExecuteExpected;
  }

  public String getCanWriteExpected() {
    return canWriteExpected;
  }

  public String getCanReadExpected() {
    return canReadExpected;
  }


  public String getCanReadActual() {
    return canReadActual;
  }

  public String getCanWriteActual() {
    return canWriteActual;
  }

  public String getCanExecuteActual() {
    return canExecuteActual;
  }
  
  public void setLocation(String location) {
    this.location = location;
  }

  public String getLocation() {
    return location;
  }

  public void setExists(boolean exists) {
    this.exists = exists;
  }
  
  public boolean exists() {
    return this.exists;
  }

}
