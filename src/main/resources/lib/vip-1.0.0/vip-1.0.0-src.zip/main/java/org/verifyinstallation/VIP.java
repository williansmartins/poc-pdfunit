/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIP.java 104 2014-08-05 20:41:41Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.Properties;
import java.util.Vector;
import java.util.jar.JarInputStream;
import java.util.zip.ZipEntry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.verifyinstallation.objective.VIPApplication;
import org.verifyinstallation.objective.VIPClass;
import org.verifyinstallation.objective.VIPClasspath;
import org.verifyinstallation.objective.VIPExecutable;
import org.verifyinstallation.objective.VIPFile;
import org.verifyinstallation.objective.VIPFileProperty;
import org.verifyinstallation.objective.VIPFolder;
import org.verifyinstallation.objective.VIPJavaRuntime;
import org.verifyinstallation.objective.VIPNativeLibrary;
import org.verifyinstallation.objective.VIPOperatingSystem;
import org.verifyinstallation.objective.VIPSystemProperty;
import org.verifyinstallation.objective.VIPUrl;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * The main class of the project VIP (Verify Installation Program).
 *
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIP {

  private VIPLogger logger;
  private Document verificationFileDOM;
  private String vipFile;
  private String outXML;
  private String stylesheet;
  private String outHTML;

  public static String defaultStylesheet = "vip-java_simple.xslt";
  public static String defaultOutputHTML = "vip_result.html";
  public static String defaultOutputXML = "vip_result.xml";
  
  private static final String pathToApplication = "/installation/application";
  private static final String pathToClasspathClasses = "/installation/classpath/class";
  private static final String pathToClasspathFiles = "/installation/classpath/file";
  private static final String pathToExecutables = "/installation/executables/executable";
  private static final String pathToFileProperties = "/installation/fileProperties/property";
  private static final String pathToFiles = "/installation/files/file";
  private static final String pathToFolders = "/installation/folders/folder";
  private static final String pathToJavaRuntime = "/installation/javaRuntime";
  private static final String pathToLibraries = "/installation/libraries/library";
  private static final String pathToOperatingSystem = "/installation/os";
  private static final String pathToSystemProperties = "/installation/systemProperties/property";
  private static final String pathToUrls = "/installation/urls/url";
  
  private static final String EMPTY_STRING = "";
  private static final String YES = "yes";
  private static final String NO = "no";

  public VIP(String vipFile) throws VIPException {
    this(vipFile, VIP.defaultStylesheet, VIP.defaultOutputHTML);
  }
  
  public VIP(String vipFile, String stylesheet) throws VIPException {
    this(vipFile, stylesheet, VIP.defaultOutputHTML);
  }
  
  public VIP(String vipFile, String stylesheet, String outHTML) throws VIPException {
    try {
      initVIP(vipFile);
      this.vipFile = vipFile;
      this.stylesheet = defaultStylesheet;
      this.outXML = createFilenameOutXML(vipFile);
      this.outHTML = createFilenameOutHTML(outHTML, vipFile);
    } catch (Exception e) {
      String msg = "Error when initializing VIP. Check commandline. Does the input file exists?";
      logger.addError(msg, e);
      throw new VIPException(e.getMessage());
    }
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // Public methods.
  /////////////////////////////////////////////////////////////////////////////
  
  public static synchronized String verifyInstallation(String vipFile, String stylesheet, String outHTML) throws TransformerException, VIPException {
    VIP vip = new VIP(vipFile, stylesheet, outHTML);
    String message = verifyAndReport(vip);
    return message;
  }

  public static synchronized String verifyInstallation(String vipFile, String stylesheetFile) throws TransformerException, VIPException {
    VIP vip = new VIP(vipFile, stylesheetFile);
    String message = verifyAndReport(vip);
    return message;
  }

  public static synchronized String verifyInstallation(String vipFile) throws TransformerException, VIPException {
    VIP vip = new VIP(vipFile);
    String message = verifyAndReport(vip);
    return message;
  }

  /**
   * Verifying that needed classes and files can be found on the classpath.
   * Files, URLs and environment setting will be logged.
   */
  public void verifyInstallation() {
    createReportHeader();
    checkOperatingSystem();
    checkJavaRuntime();
    
    logClasspath();
    checkClasspathClasses();
    checkClasspathFiles();
    
    checkFolders();
    checkFiles();
    checkURLs();
    
    checkNativeLibraries();
    checkExecutables();
    
    checkSystemProperties();
    checkFileProperties();
  }

  public boolean hasErrors() {
    return logger.hasErrors();
  }

  public void exportXML() throws TransformerException {
//    System.out.println("===> outXML: " + outXML + "<===");
    logger.exportXML(outXML);
  }

  public void exportHTML() throws TransformerException, VIPException {
    logger.exportHTML(stylesheet, outHTML);
  }

  public String getOutHTML() {
    return outHTML;
  }
  
  public String getOutXML() {
    return outXML;
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // initialization method used by the constructors:
  /////////////////////////////////////////////////////////////////////////////
  
  private void initVIP(String vipFile) throws IOException, SAXException, ParserConfigurationException {
    this.logger = new VIPLogger();
    this.vipFile = vipFile;
    InputStream vipInput = new FileInputStream(vipFile);
    this.verificationFileDOM = readVIPFile(vipInput);
  }

  private static String verifyAndReport(VIP vip) throws TransformerException, VIPException {
    vip.verifyInstallation();
    vip.exportXML();
    vip.exportHTML();
    String msg = "The configuration is OK. See the logging output in '" + vip.outHTML + "'.";
    if (vip.hasErrors()) {
      msg = "Configuration ERROR. See output file '" + vip.outHTML + "'.";
      throw new VIPException(msg);
    }
    return msg;
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // validation methods:
  /////////////////////////////////////////////////////////////////////////////
  
  private void checkJavaRuntime() {
    VIPJavaRuntime javaRuntime = getJavaRuntime();
    String javaVendor = System.getProperty("java.vendor");
    String javaSpecificationVersion = System.getProperty("java.specification.version");
    String javaClassVersion = System.getProperty("java.class.version");
    String actualJavaVersion = getActualJavaVersion();
    String actualBitSystem = getActualBitSystem();
    
    javaRuntime.setActualJavaVendor(javaVendor);
    javaRuntime.setSpecificationVersion(javaSpecificationVersion);
    javaRuntime.setClassVersion(javaClassVersion);
    javaRuntime.setActualJavaVersion(actualJavaVersion);
    javaRuntime.setActualBitSystem(actualBitSystem);
    logger.log(javaRuntime);
  }
  
  private void checkNativeLibraries() {
    Vector<VIPNativeLibrary> libraries = getNativeLibraries();
    for (VIPNativeLibrary library : libraries) {
      isLoadableNativeLibrary(library);
      logger.log(library);
    }
  }
  
  /*
   * - Read PATH from Environment
   * - Search in all Path-Elements for the Name of the process.
   * - Look for isExecutable
   * 
   * - No handling  for *.exe, *.com, *.bat. You have to define the extension.
   */
  private void checkExecutables() {
    Vector<VIPExecutable> executables = getExecutables();

    String systemPath = System.getenv("PATH");
    String pathSeprator = System.getProperty("path.separator");
    String[] pathEntries = systemPath.split(pathSeprator);

    for (VIPExecutable vipExecutable : executables) {
      String executableName = vipExecutable.getExecutableName();
      boolean found = false;
      for (String pathEntry : pathEntries) {
        File pathEntryAsFile = new File(pathEntry);
        boolean isDirectory = pathEntryAsFile.isDirectory();
        if (isDirectory) {
          FilenameFilter noFilter = null;
          String[] fileList = pathEntryAsFile.list(noFilter);
          boolean containsProcessFile = containsFile(fileList, executableName);
          if (containsProcessFile) {
            found = true;
          }
        }
        vipExecutable.setParentDirectory(pathEntryAsFile.getAbsolutePath());
        vipExecutable.foundInPath(found);
      }
      String actualOperatingSystem = getOperatingSystem();
      vipExecutable.setActualOperatingSystem(actualOperatingSystem);
      logger.log(vipExecutable);
    }
  }
  
  private void checkOperatingSystem() {
    VIPOperatingSystem os = getOS();
    String actualOperatingSystem = getOperatingSystem();
    os.setActualOperatingSystem(actualOperatingSystem);
    
    String actualBitSystem = getActualBitSystem();
    os.setActualBitSystem(actualBitSystem);

    logger.log(os);
  }

  private void checkFolders() {
    Vector<VIPFolder> folders = getFolders();
    for (VIPFolder vipFolder : folders) {
      logger.log(vipFolder);
    }
  }
  
  private void checkURLs() {
    Vector<VIPUrl> urls = getURLs();
    for (VIPUrl vipUrl : urls) {
      isReachable(vipUrl);
      logger.log(vipUrl);
    }
  }
  
  private void checkSystemProperties() {
    Vector<VIPSystemProperty> systemProperties = getSystemProperties();
    for (VIPSystemProperty systemProperty : systemProperties) {
      readSystemProperty(systemProperty);
      logger.log(systemProperty);
    }
  }

  private void checkFileProperties() {
    Vector<VIPFileProperty> fileProperties = getFileProperties();
    for (VIPFileProperty fileProperty : fileProperties) {
      readFileProperty(fileProperty);
      logger.log(fileProperty);
    }
  }
  
  private void checkFiles() {
    Vector<VIPFile> files = getFilesLoadedByFS();
    for (VIPFile vipFile : files) {
      logger.log(vipFile);
    }
  }

  private void checkClasspathFiles() {
    Vector<VIPFile> classpathFiles = getClasspathFiles();
    for (VIPFile vipFile : classpathFiles) {
      setPropertiesForFileFromClasspath(vipFile);
    }
    logger.logFilesInClasspath(classpathFiles);
  }
  
  private void checkClasspathClasses() {
    Vector<VIPClass> classes = getClasses();
    logger.log(classes);
  }
  
  private void isLoadableNativeLibrary(VIPNativeLibrary vipNativeLibrary) {
    String libraryName = vipNativeLibrary.getName();
    int extensionPosition = libraryName.toLowerCase().lastIndexOf(".dll"); // NOPMD UseLocaleWithCaseConversions
    String libraryNameWithoutExtension = libraryName;
    if (extensionPosition > -1) {
      libraryNameWithoutExtension = libraryName.substring(0, extensionPosition);
    }
    try {
      System.loadLibrary(libraryNameWithoutExtension);  // NOPMD AvoidUsingNativeCode
      vipNativeLibrary.setLoadable(true);
    } catch (Throwable e) { // NOPMD AvoidCatchingThrowable
      vipNativeLibrary.setLoadable(false);
    }
  }

  private void isReachable(VIPUrl vipUrl) {
    String location = vipUrl.getLocation();
    try {
      URL url = new URL(location);
      URLConnection urlConnection = url.openConnection();
      urlConnection.connect();
      vipUrl.setCanReadActual(true);
    } catch (Exception e) {
      vipUrl.setCanReadActual(false);
    }
  }

  private void logClasspath() {
    VIPClasspath vipClasspath = new VIPClasspath();
    String classpath = System.getProperty("java.class.path");
    String pathSeparator = System.getProperty("path.separator");
    String[] pathEntries = classpath.split(pathSeparator);
    vipClasspath.setPathEntries(pathEntries);
    logger.log(vipClasspath);
  }

  private void readSystemProperty(VIPSystemProperty systemProperty) {
    String key = systemProperty.getKey();
    String value = System.getProperty(key);
    if (value == null) {
      systemProperty.setKeyExists(false);
    } else {
      systemProperty.setKeyExists(true);
      systemProperty.setActualValue(value);
    }
  }
    
  private void readFileProperty(VIPFileProperty fileProperty) {
    try {
      String filename = fileProperty.getFilename();
      String key = fileProperty.getKey();
      File file = new File(filename);
      String absolutePath = file.getAbsolutePath();
      fileProperty.setFilename(absolutePath);
      InputStream is = new FileInputStream(file);
      Properties properties = new Properties();
      properties.load(is);
      boolean containsKey = properties.containsKey(key);
      fileProperty.setKeyExists(containsKey);
      if (containsKey) {
        String value = properties.getProperty(key);
        fileProperty.setActualValue(value);
      }
      fileProperty.setFileExists(true);
    } catch (Exception e) {
      fileProperty.setFileExists(false);
    }
  }

  /////////////////////////////////////////////////////////////////////////////
  // Methods to extract data from dom:
  /////////////////////////////////////////////////////////////////////////////
  
  private Vector<VIPExecutable> getExecutables() {
    Vector<VIPExecutable> allExecutables = new Vector<VIPExecutable>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToExecutables);
      NodeList executableNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (executableNodeList != null) {
        for (int i = 0; i < executableNodeList.getLength(); i++) {
          VIPExecutable vipExecutable = new VIPExecutable();
          Node executableNode = executableNodeList.item(i);
          NamedNodeMap attributes = executableNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("name".equals(attributeName)) {
              vipExecutable.setExecutableName(attributeValue);
            }
            if ("os".equals(attributeName)) {
              vipExecutable.setExpectedOperatingSystem(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipExecutable.setComment(attributeValue);
            }
          }
          allExecutables.add(vipExecutable);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToExecutables + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allExecutables;
  }

  private String getActualJavaVersion() {
    String actualJavaVersion = System.getProperty("java.version");
    return actualJavaVersion;
  }
  
  private VIPJavaRuntime getJavaRuntime() {
    VIPJavaRuntime vipJavaRuntime = new VIPJavaRuntime();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToJavaRuntime);
      Node javaRuntimeNode = (Node) expr.evaluate(verificationFileDOM, XPathConstants.NODE);
      if (javaRuntimeNode != null) {
        NamedNodeMap attributes = javaRuntimeNode.getAttributes();
        for (int i = 0; i < attributes.getLength(); i++) {
          Node attribute = attributes.item(i);
          String attributeName = attribute.getNodeName();
          String attributeValue = attribute.getNodeValue();
          
          if ("comment".equals(attributeName)) {
            vipJavaRuntime.setComment(attributeValue);
          }
          if ("bitSystem".equals(attributeName)) {
            vipJavaRuntime.setExpectedBitSystem(attributeValue);
          }
          if ("version".equals(attributeName)) {
            vipJavaRuntime.setVersion(attributeValue);
          }
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToJavaRuntime + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return vipJavaRuntime;
  }

  private VIPOperatingSystem getOS() {
    VIPOperatingSystem vipOperatingSystem = new VIPOperatingSystem();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToOperatingSystem);
      Node osNode = (Node) expr.evaluate(verificationFileDOM, XPathConstants.NODE);
      if (osNode != null) {
        NamedNodeMap attributes = osNode.getAttributes();
        for (int i = 0; i < attributes.getLength(); i++) {
          Node attribute = attributes.item(i);
          String attributeName = attribute.getNodeName();
          String attributeValue = attribute.getNodeValue();
          
          if ("name".equals(attributeName)) {
            vipOperatingSystem.setExpectedName(attributeValue);
          }
          if ("comment".equals(attributeName)) {
            vipOperatingSystem.setComment(attributeValue);
          }
          if ("bitSystem".equals(attributeName)) {
            vipOperatingSystem.setExpectedBitSystem(attributeValue);
          }
          if ("versions".equals(attributeName)) {
            vipOperatingSystem.setExpectedOSVersions(attributeValue);
          }
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToOperatingSystem + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return vipOperatingSystem;
  }

  private Vector<VIPNativeLibrary> getNativeLibraries() {
    Vector<VIPNativeLibrary> allLibraries = new Vector<VIPNativeLibrary>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToLibraries);
      NodeList libraryNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (libraryNodeList != null) {
        for (int i = 0; i < libraryNodeList.getLength(); i++) {
          VIPNativeLibrary vipNativeLibrary = new VIPNativeLibrary();
          Node libraryNode = libraryNodeList.item(i);
          NamedNodeMap attributes = libraryNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("name".equals(attributeName)) {
              vipNativeLibrary.setName(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipNativeLibrary.setComment(attributeValue);
            }
          }
          allLibraries.add(vipNativeLibrary);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToLibraries + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allLibraries;
  }

  private Vector<VIPFolder> getFolders() {
    Vector<VIPFolder> allFolders = new Vector<VIPFolder>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToFolders);
      NodeList foldersNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (foldersNodeList != null) {
        for (int i = 0; i < foldersNodeList.getLength(); i++) {
          VIPFolder vipFolder = new VIPFolder();
          Node folderNode = foldersNodeList.item(i);
          NamedNodeMap attributes = folderNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("name".equals(attributeName)) {
              vipFolder.setName(attributeValue);
            }
            if ("canRead".equals(attributeName)) {
              vipFolder.setCanReadExpected(attributeValue);
            }
            if ("canWrite".equals(attributeName)) {
              vipFolder.setCanWriteExpected(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipFolder.setComment(attributeValue);
            }
          }
          allFolders.add(vipFolder);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToFolders + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allFolders;
  }

  private VIPApplication getApplication() {
    VIPApplication application = new VIPApplication();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToApplication);
      Node applicationNode = (Node) expr.evaluate(verificationFileDOM, XPathConstants.NODE);
      if (applicationNode != null) {
        NamedNodeMap attributes = applicationNode.getAttributes();
        for (int i = 0; i < attributes.getLength(); i++) {
          Node attributeNode = attributes.item(i);
          String nodeName = attributeNode.getNodeName();
          String nodeValue = attributeNode.getNodeValue();
          if ("product".equals(nodeName)) {
            application.setProduct(nodeValue);
          }
          if ("version".equals(nodeName)) {
            application.setVersion(nodeValue);
          }
          if ("comment".equals(nodeName)) {
            application.setComment(nodeValue);
          }
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToApplication + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return application;
  }

  private Vector<VIPFile> getFilesLoadedByFS() {
    Vector<VIPFile> allFiles = new Vector<VIPFile>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToFiles);
      NodeList filesNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (filesNodeList != null) {
        for (int i = 0; i < filesNodeList.getLength(); i++) {
          VIPFile vipFile = new VIPFile();
          Node fileNode = filesNodeList.item(i);
          NamedNodeMap attributes = fileNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("name".equals(attributeName)) {
              vipFile.setName(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipFile.setComment(attributeValue);
            }
            if ("canRead".equals(attributeName)) {
              vipFile.setCanReadExpected(attributeValue);
            }
            if ("canWrite".equals(attributeName)) {
              vipFile.setCanWriteExpected(attributeValue);
            }
            if ("canExecute".equals(attributeName)) {
              vipFile.setCanExecuteExpected(attributeValue);
            }
          }
          allFiles.add(vipFile);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToFiles + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allFiles;
  }

  private Vector<VIPUrl> getURLs() {
    Vector<VIPUrl> allUrls = new Vector<VIPUrl>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToUrls);
      NodeList urlNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (urlNodeList != null) {
        for (int i = 0; i < urlNodeList.getLength(); i++) {
          VIPUrl vipUrl = new VIPUrl();
          Node urlNode = urlNodeList.item(i);
          NamedNodeMap attributes = urlNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("location".equals(attributeName)) {
              vipUrl.setLocation(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipUrl.setComment(attributeValue);
            }
          }
          allUrls.add(vipUrl);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToUrls + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allUrls;
  }

  private void createReportHeader() {
    try {
      VIPApplication application = getApplication();
      String currentDir = new File(".").getCanonicalPath();
      application.setWorkDirectory(currentDir);
      logger.log(application);
    } catch (IOException e) {
      ; // ignore exception, because the current dir "." exists always
    }
  }

  private Vector<VIPClass> getClasses() {
    Vector<VIPClass> allClasses = new Vector<VIPClass>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToClasspathClasses);
      NodeList classNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (classNodeList != null) {
        for (int i = 0; i < classNodeList.getLength(); i++) {
          VIPClass vipNodeClass = new VIPClass();
          Node classNode = classNodeList.item(i);
          NamedNodeMap attributes = classNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("name".equals(attributeName)) {
              vipNodeClass.setClass(attributeValue);
              boolean loadable = isLoadable(attributeValue);
              vipNodeClass.setLoadable(loadable);
              String classLocation = getClassLocation(attributeValue);
              vipNodeClass.setLocation(classLocation);
              String classVersion = getClassVersion(attributeValue);
              vipNodeClass.setClassVersion(classVersion);
            }
            if ("comment".equals(attributeName)) {
              vipNodeClass.setComment(attributeValue);
            }
          }
          allClasses.add(vipNodeClass);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToClasspathClasses + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allClasses;
  }

  private Vector<VIPFile> getClasspathFiles() {
    Vector<VIPFile> allFiles = new Vector<VIPFile>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToClasspathFiles);
      NodeList classpathNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (classpathNodeList != null) {
        for (int i = 0; i < classpathNodeList.getLength(); i++) {
          VIPFile vipFile = new VIPFile();
          Node classNode = classpathNodeList.item(i);
          NamedNodeMap attributes = classNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("name".equals(attributeName)) {
              vipFile.setName(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipFile.setComment(attributeValue);
            }
            if ("canRead".equals(attributeName)) {
              vipFile.setCanReadExpected(attributeValue);
            }
            if ("canWrite".equals(attributeName)) {
              vipFile.setCanWriteExpected(attributeValue);
            }
            if ("canExecute".equals(attributeName)) {
              vipFile.setCanExecuteExpected(attributeValue);
            }
          }
          allFiles.add(vipFile);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToClasspathFiles + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allFiles;
  }
  
  private Vector<VIPSystemProperty> getSystemProperties() {
    Vector<VIPSystemProperty> allProperties = new Vector<VIPSystemProperty>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToSystemProperties);
      NodeList systemPropertiesNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (systemPropertiesNodeList != null) {
        for (int i = 0; i < systemPropertiesNodeList.getLength(); i++) {
          VIPSystemProperty vipSystemProperty = new VIPSystemProperty();
          Node systemPropertyNode = systemPropertiesNodeList.item(i);
          NamedNodeMap attributes = systemPropertyNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("key".equals(attributeName)) {
              vipSystemProperty.setKey(attributeValue);
            }
            if ("expected".equals(attributeName)) {
              vipSystemProperty.setExpectedValue(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipSystemProperty.setComment(attributeValue);
            }
          }
          allProperties.add(vipSystemProperty);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToSystemProperties + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allProperties;
  }

  private Vector<VIPFileProperty> getFileProperties() {
    Vector<VIPFileProperty> allProperties = new Vector<VIPFileProperty>();
    try {
      XPathFactory xPathfactory = XPathFactory.newInstance();
      XPath xpath = xPathfactory.newXPath();
      XPathExpression expr = xpath.compile(pathToFileProperties);
      NodeList filePropertiesNodeList = (NodeList) expr.evaluate(verificationFileDOM, XPathConstants.NODESET);
      if (filePropertiesNodeList != null) {
        for (int i = 0; i < filePropertiesNodeList.getLength(); i++) {
          VIPFileProperty vipFileProperty = new VIPFileProperty();
          Node filePropertyNode = filePropertiesNodeList.item(i);
          NamedNodeMap attributes = filePropertyNode.getAttributes();
          for (int k = 0; k < attributes.getLength(); k++) {
            Node attribute = attributes.item(k);
            String attributeName = attribute.getNodeName();
            String attributeValue = attribute.getNodeValue();
            if ("file".equals(attributeName)) {
              vipFileProperty.setFilename(attributeValue);
            }
            if ("key".equals(attributeName)) {
              vipFileProperty.setKey(attributeValue);
            }
            if ("expected".equals(attributeName)) {
              vipFileProperty.setExpectedValue(attributeValue);
            }
            if ("comment".equals(attributeName)) {
              vipFileProperty.setComment(attributeValue);
            }
          }
          allProperties.add(vipFileProperty);
        }
      }
    } catch (Exception e) {
      String msg = e.getMessage();
      msg = "Error reading VIP file. Problem with XPath '" + pathToFileProperties + "'." + "\n" + msg;
      logger.addError(msg, e);
    }
    return allProperties;
  }
  
  /////////////////////////////////////////////////////////////////////////////
  // helper methods:
  /////////////////////////////////////////////////////////////////////////////

  private String createFilenameOutHTML(String outHTML, String vipFile) {
    if (VIP.defaultOutputHTML.equals(outHTML)) {
      return vipFile + ".out.html";
    } else {
      return outHTML;
    }
  }

  private String createFilenameOutXML(String vipFile) {
    return vipFile + ".out.xml";
  }
  
  private String getSourceLocation(CodeSource source) {
    if(source == null) {
      String javaHome = System.getProperty("java.home");
      return "(Current Java runtime, 'java.home' = " + javaHome + ")";
    } else {
      URL location = source.getLocation();
      return location.toString();
    }
  }
  
  private void setPropertiesForFileFromClasspath(VIPFile vipFile) {
    String filename = vipFile.getName();
    vipFile.setName(filename);
    URL resourceURL = VIPMain.class.getClassLoader().getResource(filename);
    if (resourceURL == null) {
      vipFile.setExists(false);
      return;
    } else {
      vipFile.setExists(true);
    }
    String protocol = resourceURL.getProtocol();
    if (protocol.equals("jar")) {
      vipFile.setCanReadActual(YES);
      vipFile.setCanWriteActual(NO);
      vipFile.setCanExecuteActual(NO);
      String location = createAbsoluteFilename(resourceURL);
      location = location.replaceFirst("file:", "");
      vipFile.setLocation(location);
    } else {
      String location = createAbsoluteFilename(resourceURL);
      vipFile.setLocation(location);
    }
  }

  private String createAbsoluteFilename(URL resourceURL) {
    String resourceFileName = resourceURL.getFile();
    File resourceAsFile = new File(resourceFileName);
    String parentFolder = resourceAsFile.getParent();
    return parentFolder;
  }

  private Document readVIPFile(InputStream vipStream) throws IOException, SAXException, ParserConfigurationException {
    try {
      DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      Document dom = dBuilder.parse(vipStream);
      return dom;
    } catch (ParserConfigurationException e) {
      String msg = "Error parsing the VIP file '" + this.vipFile + "'.";
      logger.addError(msg, e);
      throw e;
    } catch (SAXException e) {
      String msg = "Error parsing the VIP file '" + this.vipFile + "'.";
      logger.addError(msg, e);
      throw e;
    } catch (IOException e) {
      String msg = "Error reading VIP file '" + this.vipFile + "' could not be read.";
      logger.addError(msg, e);
      throw e;
    }
  }

  /**
   * Explain the command line parameter.
   * Usage:
   * <p>
   * java org.verifyinstallation.VIPMain --in <verification-file.vip> --out <output-file.xml>");
   * </p>
   */
  public static void showUsage() {
    System.out.println();
    System.out.println("Usage of VIP (Verify Installation Program):");
    System.out.println();
    System.out.println("   java org.verifyinstallation.VIPMain --in <verification-file.vip> [OPTIONS]");
    System.out.println();
    System.out.println("OPTIONS:");
    System.out.println();
    System.out.println("   --out  <output-file.html>      relative or absolute path to the report to be generated");
    System.out.println("                                  default is 'vip_result.html'                           ");
    System.out.println("   --xslt <stylesheet-file.xslt>  relative or absolute path to XSLT-Stylesheet");
    System.out.println("                                  default is 'vip-java_simple.xslt', comming from vip*.jar");
    System.out.println();
    System.out.println();
  }
  
  private String getOperatingSystem() {
    String osName = System.getProperty("os.name").toLowerCase(); // NOPMD UseLocaleWithCaseConversions
    return osName;
  }
  
  private String getActualBitSystem() {
    String osArch = System.getProperty("os.arch");
    return osArch;
  }
  
  private boolean containsFile(String[] fileList, String expectedFile) {
    for (String filename : fileList) {
      if (filename.equals(expectedFile)) {
        return true;
      }
    }
    return false;
  }

  private String getClassLocation(String className) {
    try {
      Class<?> clazz = Class.forName(className);
      ProtectionDomain protectionDomain = clazz.getProtectionDomain();
      CodeSource source = protectionDomain.getCodeSource();
      String sourceLocation = getSourceLocation(source);
      return sourceLocation;
    } catch (Throwable e) {   // NOPMD AvoidCatchingThrowable
      return EMPTY_STRING;
    }
  }

  private String getClassVersion(String className) {
    try {
      return getVersionOfFileFromClasspath(className);
    } catch (NullPointerException e) {
      return getVersionOfClassInsideJar(className);
    } catch (IOException e) {
      return className + " could not be read from classpath";
    }
  }
  
  private boolean isLoadable(String className) {
    try {
      Class.forName(className);
      return true;
    } catch (Throwable e) {   // NOPMD AvoidCatchingThrowable
      return false;
    }
  }

  private String getVersionOfFileFromClasspath(String className) throws IOException {
    String fileName = createFileName(className);
    InputStream is = this.getClass().getClassLoader().getResourceAsStream(fileName);
    if (is == null) {
      throw new NullPointerException( className + "is not readable as file. Look for it in JAR's.");
    }
    DataInputStream data = new DataInputStream(is);
    if (data.readInt() != 0xCAFEBABE) {
      throw new IOException("invalid header");
    }
    int minor = data.readUnsignedShort();
    int major = data.readUnsignedShort();
    return major + "." + minor;
  }

  private String createFileName(String fileName) {
    fileName = fileName.replaceAll("\\.", "/");
    fileName = fileName + ".class";
    return fileName;
  }

  private String getVersionOfClassInsideJar(String className) {
    try {
      String jarName = getJarName(className);

      FileInputStream jarFis = new FileInputStream(jarName);
      JarInputStream jarInputStream = new JarInputStream(jarFis);
      ZipEntry nextEntry = jarInputStream.getNextEntry();
      while (nextEntry != null) {      
        String nextEntryName = nextEntry.getName();
        String entryNameAsClassname = convertFilenameToClassname(nextEntryName);
        if (entryNameAsClassname.equals(className)) {
          DataInputStream data = new DataInputStream(jarInputStream);
          if (data.readInt() != 0xCAFEBABE) {
            data.close();
            return "invalid header of the class file";
          }
          int minor = data.readUnsignedShort();
          int major = data.readUnsignedShort();
          data.close();
          return major + "." + minor;
        }
        nextEntry = jarInputStream.getNextEntry();
      }
      jarInputStream.close();
      return "class not found in JAR";
    } catch (FileNotFoundException e) {
      return "file not found in JAR";
    } catch (IOException e) {
      return "error reading file. Msg :" + e.getMessage();
    }
  }

  private String convertFilenameToClassname(String zipEntryName) {
    String className = zipEntryName.replaceAll("/", "\\.");
    int indexOfFileExtension = className.lastIndexOf(".class");
    className = className.substring(0, indexOfFileExtension);
    return className;
  }

  private String getJarName(String className) {
    try {
      Class<?> clazz = Class.forName(className);
      ProtectionDomain protectionDomain = clazz.getProtectionDomain();
      CodeSource source = protectionDomain.getCodeSource();
      if(source == null) {
        String javaHome = System.getProperty("java.home");
        return javaHome + "\\lib\\rt.jar";
      } else {
        URL location = source.getLocation();
        return location.toString();
      }
    } catch (Throwable e) {   // NOPMD AvoidCatchingThrowable
      return "TODO";
    }
  }

}
