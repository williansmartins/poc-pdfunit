/* ***************************************************************************
 *                                                                           *
 * VIP - Verify Installation Program                                         *
 *                                                                           *
 * Copyright (C) 2013 www.verify-installation.org                            *
 *                                                                           *
 * This file is part of the OpenSource Project VIP                           *
 *                                                                           *
 * Documentation_________: http://verify-installation.org/howto/             *
 * Contact_______________: info@verify-installation.org                      *
 *                                                                           *
 *************************************************************************** *
 * $Id: VIPTest.java 97 2013-10-28 07:39:47Z csiedentop $
 *************************************************************************** */
package org.verifyinstallation;

import static org.junit.Assert.*;

import org.junit.Test;
import org.verifyinstallation.VIP;
import org.verifyinstallation.VIPException;

/**
 * These tests test the VIP itself.
 * 
 * The methods verifies, that all needed libraries and files are found on the 
 * classpath. Additionally it logs some system properties and writes 
 * all to System.out.
 * 
 * @author Carsten Siedentop
 * @since October 2013
 */
public class VIPTest {

  // TODO more tests 
  // TODO Tests with XML and HTML result
  // TODO use other vip files
  // TODO look critically over the method names
  
  private static final boolean ERRORS_EXPECTED = true;
  
  @Test
  public void verifyNeededFilesAndLibraries() throws Exception {
    VIP vip = new VIP("src/test/resources/demo1.vip");
    vip.verifyInstallation();
    boolean result = vip.hasErrors();
    assertEquals("This file should have errors.", ERRORS_EXPECTED, result);
  }
  
  @Test
  public void verifyNeededFilesAndLibraries_WithStylesheet() throws Exception {
    VIP vip = new VIP("src/test/resources/demo1.vip", "vip-java_simple.xslt");
    vip.verifyInstallation();
    boolean result = vip.hasErrors();
    assertEquals("This file should have errors.", ERRORS_EXPECTED, result);
  }
  
  @Test(expected=VIPException.class)
  public void verifyNeededFilesAndLibraries_StaticValidation() throws Exception {
    VIP.verifyInstallation("src/test/resources/demo1.vip");
  }
  
  @Test(expected=VIPException.class)
  public void verifyNeededFilesAndLibraries_StaticValidation_WithStylesheet() throws Exception {
    VIP.verifyInstallation("src/test/resources/demo1.vip", "vip-java_simple.xslt");
  }
  
  @Test
  public void verifyVIP_minimalFile() throws Exception {
    VIP.verifyInstallation("src/test/resources/minimal_file.vip");
  }
  
  @Test
  public void verifyVIP_WithStylesheet() throws Exception {
    VIP.verifyInstallation("src/test/resources/minimal_file.vip", "vip-java_simple.xslt");
  }
  
  @Test
  public void verifyVIP_WithStylesheetAndOutput() throws Exception {
    VIP.verifyInstallation("src/test/resources/minimal_file.vip", "vip-java_simple.xslt", "minimal_file.out.html");
  }
  
}
